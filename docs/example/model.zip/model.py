def predict(percentages, evaluation_model):
    mark = '2'
    for key, value in evaluation_model.items():
        if value <= percentages:
            mark = key
    return mark

return predict(percentages, model)
